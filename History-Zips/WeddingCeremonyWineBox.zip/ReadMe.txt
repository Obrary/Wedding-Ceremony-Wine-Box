Product: Wedding Ceremony Wine Box, September 2014
Designer: Scott Austin, scotta@obrary.com
Support:  support@obrary.com
Distributed by:  Obrary, Inc.  http://obrary.com.  Obrary is a marketplace of products collaboratively designed by the community. These products can be produced by anyone, amateur or professional manufacturer, wherever economically or locally practical.

Description:
The wine box is designed to be cut from 1/4" plywood on a Laser Cutter.

Files included in this package:
 - WeddingCermonyWineBox.skp - this is the 3D model in SketchUp.  SketchUp can be installed for free at http://www.sketchup.com/download
 - WeddingCeremonyWineBox.dxf - this is the 2D plan of the design that can be opened in a variety of applications
 - WeddingCeremonyWineBox.pdf - another format of the 2D plan of the design
 - ReadMe.txt - this file